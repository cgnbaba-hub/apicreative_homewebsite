---
name: Helvetia Digital
colors:
  surface: '#faf8fe'
  surface-dim: '#dad9df'
  surface-bright: '#faf8fe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f8'
  surface-container: '#eeedf3'
  surface-container-high: '#e9e7ed'
  surface-container-highest: '#e3e2e7'
  on-surface: '#1a1b1f'
  on-surface-variant: '#5c403b'
  inverse-surface: '#2f3034'
  inverse-on-surface: '#f1f0f5'
  outline: '#916f6a'
  outline-variant: '#e6bdb7'
  surface-tint: '#be0f09'
  primary: '#b50303'
  on-primary: '#ffffff'
  primary-container: '#da291c'
  on-primary-container: '#fff5f3'
  inverse-primary: '#ffb4a8'
  secondary: '#5f5e60'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfe1'
  on-secondary-container: '#636264'
  tertiary: '#005b9f'
  on-tertiary: '#ffffff'
  tertiary-container: '#0074c8'
  on-tertiary-container: '#f5f7ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad4'
  primary-fixed-dim: '#ffb4a8'
  on-primary-fixed: '#410000'
  on-primary-fixed-variant: '#930001'
  secondary-fixed: '#e4e2e4'
  secondary-fixed-dim: '#c8c6c8'
  on-secondary-fixed: '#1b1b1d'
  on-secondary-fixed-variant: '#474649'
  tertiary-fixed: '#d2e4ff'
  tertiary-fixed-dim: '#a1c9ff'
  on-tertiary-fixed: '#001c37'
  on-tertiary-fixed-variant: '#004880'
  background: '#faf8fe'
  on-background: '#1a1b1f'
  surface-variant: '#e3e2e7'
typography:
  display:
    fontFamily: Inter
    fontSize: 5rem
    fontWeight: '700'
    lineHeight: 5.25rem
    letterSpacing: -0.04em
  display-mobile:
    fontFamily: Inter
    fontSize: 2.75rem
    fontWeight: '700'
    lineHeight: 3rem
    letterSpacing: -0.03em
  headline-xl:
    fontFamily: Inter
    fontSize: 3.5rem
    fontWeight: '600'
    lineHeight: 3.75rem
    letterSpacing: -0.035em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 2.5rem
    fontWeight: '600'
    lineHeight: 2.75rem
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.125rem
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Inter
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.625rem
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Inter
    fontSize: 1.25rem
    fontWeight: '400'
    lineHeight: 1.875rem
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
    letterSpacing: 0em
  label-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.02em
  eyebrow:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
  space-3xl: 6rem
---

## Brand & Style

The visual identity embodies the intersection of classical International Typographic Style (Swiss Modernism) and contemporary Cupertino product engineering. The personality is rational, authoritative, surgically precise, and quietly confident. 

Targeted at high-growth European enterprises, institutions, and visionary product leaders, the design evokes intellectual clarity, absolute reliability, and uncompromising digital craftsmanship.

The aesthetic philosophy is rooted in architectural minimalism:
- **Purity of Structure:** Layouts are anchored by strict structural alignment, deliberate negative space, and mathematical proportions.
- **Graphic Intentionality:** Every element on screen must serve a functional purpose; decorative ornamentation is strictly avoided.
- **Typographic Precision:** Content hierarchy is driven through strict weight contrast and tight tracking rather than arbitrary decorative elements.
- **Orthographic Accuracy:** German text strictly adheres to Swiss typographic standards, replacing 'ß' with 'ss' universally (e.g., *Grossunternehmen*, *schliessen*).

## Colors

The palette operates on extreme restraint, allowing content, form, and typography to dominate.

- **Canvas Background (`#FAFAFA`):** A warm off-white surface that eliminates digital glare while retaining a stark, clean baseline.
- **Pure Surface (`#FFFFFF`):** Reserved exclusively for elevated cards, nested modules, and floating interface layers.
- **Deep Slate (`#1D1D1F`):** The primary structural and typographical color. Delivers sharp contrast without the harshness of pure black.
- **Muted Neutral (`#86868B`):** Applied to secondary metadata, auxiliary body copy, captions, and inactive indicator states.
- **Precision Border (`#E5E5EA`):** A hairline stroke used to define boundaries and structure containers without visual noise.
- **Swiss Red (`#DA291C`):** High-signal primary accent. Used strictly and sparingly for primary call-to-actions, active indicators, and critical navigational highlights. It must never exceed 5% of the visible viewport area to preserve its functional impact.

## Typography

Typography delivers the core structural texture of this design system. Inter is deployed across all scales, leaning on high optical clarity and tightly engineered glyph proportions.

- **Display & Headlines:** Headings utilize negative tracking (tightened kerning) down to `-0.04em` on monumental sizes. Line heights are kept tightly calibrated to allow bold, monumental multi-line statements reminiscent of Apple editorial pages.
- **Eyebrows & Metadata:** Uppercase micro-labels leverage wide tracking (`+0.08em`) paired with 600 weight to anchor content blocks.
- **Orthographic Directive:** In all German language contexts, avoid the ligature 'ß'. Substitute with 'ss' without exception, maintaining authentic Swiss standard orthography.
- **Numerical Data:** Tabular numerals (`tnum`) must be active on pricing tables, data visualizations, and operational statistics to enforce vertical column alignment.

## Layout & Spacing

Layouts follow a strict, mathematically disciplined 12-column grid system designed around intentional emptiness.

- **Desktop (1200px+):** 12 columns, 1.5rem gutters, with a maximum layout container width of 1280px or 1440px for expansive presentation layouts. Margin bounds sit at 3rem minimum.
- **Tablet (768px - 1199px):** 8 columns, 1.5rem gutters, 2rem margins.
- **Mobile (below 768px):** 4 columns, 1rem gutters, 1.25rem margins. Multi-column editorial modules collapse systematically into linear vertical stacks.
- **Rhythm & Whitespace:** Generous vertical rhythm separates major concepts. Section margins regularly employ `space-2xl` (64px) and `space-3xl` (96px) to let typography breathe. Visual mass should feel lightweight, precise, and unbound.

## Elevation & Depth

Depth is conveyed through flat surface contrast, precision keylines, and subtle ambient light simulation rather than dramatic dropshadows:

- **Surface Layering:** The primary canvas sits at `#FAFAFA`. Cards and interactive planes rest at pure `#FFFFFF`.
- **Structural Keylines:** Borders use a single 1px solid stroke in `#E5E5EA`. When items are hovered or focused, transitions shift to `#1D1D1F` or `#DA291C` without shifting layout dimensions.
- **Micro-Shadows:** Surfaces use an ultra-diffused dual shadow:
  - Default: `0 1px 2px 0 rgba(0, 0, 0, 0.04), 0 2px 8px 0 rgba(0, 0, 0, 0.02)`
  - Elevated / Interactive Hover: `0 2px 4px 0 rgba(0, 0, 0, 0.04), 0 12px 24px -4px rgba(0, 0, 0, 0.06)`
- **Frosted Glass Navigation:** Translucent navigation bars feature a backdrop filter blur (`backdrop-filter: blur(20px) saturate(180%)`) with background color set to `rgba(250, 250, 250, 0.8)`.

## Shapes

The geometric architecture balances classical modernist right-angle structure with refined contemporary corner radii.

- Standard buttons, form fields, and chip badges utilize 0.5rem (8px) corners, producing an organic yet controlled silhouette.
- Large cards, interactive media containers, and modal sheets adopt 1rem (16px) or 1.5rem (24px) continuous squircle-approximated radii, echoing Apple hardware corners.
- Avatar badges and specific micro-status indicators retain a continuous circle / pill geometry.

## Components

### Buttons
- **Primary Action:** Solid Swiss Red (`#DA291C`) background, `#FFFFFF` typography, 0.5rem radius, zero border. Smooth transition on hover to `#B82015`.
- **Secondary Action:** `#1D1D1F` background, `#FFFFFF` typography, 0.5rem radius. Used for executive navigation and standard confirmation actions.
- **Tertiary (Ghost / Outline):** Transparent background, 1px `#E5E5EA` border, `#1D1D1F` typography. Hover states introduce a subtle `#F5F5F7` surface tint and `#1D1D1F` border.
- **Padding:** 0.75rem vertical by 1.5rem horizontal for regular desktop buttons; 0.5rem by 1rem for compact interfaces.

### Cards & Modules
- Pure white (`#FFFFFF`) surface set against the `#FAFAFA` canvas.
- Crisp 1px `#E5E5EA` hairline border.
- Generous internal padding (`space-xl` / 2.5rem desktop, `space-lg` / 1.5rem mobile).
- Interactive cards feature an ambient hover shadow elevation and subtle 2px upward Y-axis translation.

### Form Inputs & Controls
- **Text Inputs:** Background `#FFFFFF`, 1px `#E5E5EA` border, 0.5rem radius, height 48px. Placeholder in `#86868B`. Focus state is defined by a crisp 1px `#1D1D1F` border and an outline-free micro-shadow ring.
- **Checkboxes & Radios:** 18px dimensions, 1px border. Checked state fills with `#DA291C` featuring an exact optical white check icon.

### Chips & Badges
- `#F5F5F7` neutral background, `#1D1D1F` typography, 0.25rem or pill radius.
- Accent badges apply an ultra-subtle tint (`rgba(218, 41, 28, 0.08)`) with `#DA291C` label typography.

### Lists & Tables
- Borderless rows separated only by 1px horizontal `#E5E5EA` dividers.
- Row items maintain vertical padding of 1.25rem with tabular-aligned figures and balanced typographic columns.
- Hover states transition cleanly to `#F5F5F7` across full row widths.